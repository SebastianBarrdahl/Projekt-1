<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel = "stylesheet" type="text/css" href="media_style.css" />

<title>Contact</title>
</head>

<body>

<!-- Navbar list
-->

<ul class="navbar_ul">
  <li class="navbar_li" class="silverbackground"><a href="index.php">Home</a></li>
  <li class="navbar_li"><a href="movie_list.php">Movies</a></li>
  <li class="navbar_li" style="background-color:gray"><a href="contact.php">Contact</a></li>
  <li class="navbar_li" style="float:right"><a href="logout.php">Log-out</a></li>
  
</ul> 

<h2>Contact me at seba01001@utb.vaxjo.se</h2>

</body>

</html>
